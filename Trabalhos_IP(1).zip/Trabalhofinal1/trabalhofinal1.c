#include<stdio.h>
int main(){
void blue () {
  printf("\033[0;34m"); 
}
blue();
printf("┌───────────────────────────────────────────────────────────────────────────────────────────┐\n");
printf("│ ███████████                              █████   █████  ███                 █████         │\n");
printf("│░░███░░░░░███                            ░░███   ░░███  ░░░                 ░░███          │\n");
printf("│ ░███    ░███  ██████  █████████████      ░███    ░███  ████  ████████    ███████   ██████ │\n");
printf("│ ░██████████  ███░░███░░███░░███░░███     ░███    ░███ ░░███ ░░███░░███  ███░░███  ███░░███│\n");
printf("│ ░███░░░░░███░███████  ░███ ░███ ░███     ░░███   ███   ░███  ░███ ░███ ░███ ░███ ░███ ░███│\n");
printf("│ ░███    ░███░███░░░   ░███ ░███ ░███      ░░░█████░    ░███  ░███ ░███ ░███ ░███ ░███ ░███│\n");
printf("│ ███████████ ░░██████  █████░███ █████       ░░███      █████ ████ █████░░████████░░██████ │\n");
printf("│░░░░░░░░░░░   ░░░░░░  ░░░░░ ░░░ ░░░░░         ░░░      ░░░░░ ░░░░ ░░░░░  ░░░░░░░░  ░░░░░░  │\n");         
printf("│                                                                                           │\n");
printf("│                                                                                           │\n");
printf("│                                                                                           │\n");
printf("│                                                                                           │\n");
printf("│                                                                                           │\n");
printf("│                                  ██████    ██████                                         │\n");
printf("│                                 ░░░░░███  ███░░███                                        │\n"); 
printf("│                                  ███████ ░███ ░███                                        │\n");
printf("│                                 ███░░███ ░███ ░███                                        │\n");
printf("│                                ░░████████░░██████                                         │\n");
printf("│                                 ░░░░░░░░  ░░░░░░                                          │\n");
printf("│                                                                                           │\n");
printf("│                                                                                           │\n");
printf("│                                                                                           │\n");
printf("│   █████████                                                                               │\n");
printf("│  ███░░░░░███                                                                              │\n");
printf("│ ███     ░░░   ██████  ████████   █████ █████  ██████  ████████   █████   ██████  ████████ │\n");
printf("│░███          ███░░███░░███░░███ ░░███ ░░███  ███░░███░░███░░███ ███░░   ███░░███░░███░░███│\n");
printf("│░███         ░███ ░███ ░███ ░███  ░███  ░███ ░███████  ░███ ░░░ ░░█████ ░███ ░███ ░███ ░░░ │\n");
printf("│░░███     ███░███ ░███ ░███ ░███  ░░███ ███  ░███░░░   ░███      ░░░░███░███ ░███ ░███     │\n");
printf("│ ░░█████████ ░░██████  ████ █████  ░░█████   ░░██████  █████     ██████ ░░██████  █████    │\n");
printf("│  ░░░░░░░░░   ░░░░░░  ░░░░ ░░░░░    ░░░░░     ░░░░░░  ░░░░░     ░░░░░░   ░░░░░░  ░░░░░     │\n");
printf("└───────────────────────────────────────────────────────────────────────────────────────────┘\n");
//loop para o ususário fazer quantas conversões ele quiser, sem precisar executar o arquivo novamente
while(1) {
//mostrando para o usuário quais os tipos de conversões que é possivel de se fazer com o programa 
printf("Olá, digite o número de quais medidas você gostaria de converter hoje.\n");
 	printf("1. Temperaturas\n");
 	printf("2. Distância\n");
 	printf("3. Velocidade\n");
 	printf("4. Peso\n");
 	printf("5. Tempo\n");
 	printf("6. Volume\n");
 	printf("7. Créditos\n");
 	printf("8. Sair\n");
 	int escolha1;
 	//declarando a variável que dirá para o programa qual o tipo de conversão que o usuário quer
 	scanf("%int",&escolha1);
 	//condição para que o código passe a executar as conversoes de temperaturas 
 	if (escolha1 == 1) {
 		printf("Legal!! É sempre bom fazer a conversão de Temperaturas.\n");
 		//mostrando quais os tipos de conversões de temperatura o código pode executar
 		printf("Qual o tipo de conversão você gostaria de fazer hoje?\n");
 		printf("1. Celsius para Fahrenheit\n");
 		printf("2. Celsius para Kelvin\n");
 		printf("3. Fahrenheit para Celsius\n");
 		printf("4. Fahrenheit para Kelvin\n");
 		printf("5. Kelvin para Celsius\n");
 		printf("6. Kelvin para Fahrenheit\n");
 		//declarando uma variável para definir qual o tipo epecífico de conversão de temperatura o usuário quer fazer
 		int escolha2;
 		double celsius, fahrenheit, kelvin;
 		scanf("%d",&escolha2);
 		//condições para que cada tipo específico de conversão de temperatura seja executada
 	       if(escolha2 == 1) {
 			printf("Digite o valor em Celsius\n");
 			double celsius,fahrenheit;
 			scanf("%lf",&celsius);
 			fahrenheit = (celsius*1.8) + 32;               //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf graus Celsius em Fahrenheit é %.2lf\n", celsius, fahrenheit); 
 			}
 		if(escolha2 == 2) {
 			printf("Digite o valor em Celsius\n");
 			double celsius, kelvin;
 			scanf("%lf",&celsius);
 			kelvin = celsius + 273;            //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf graus Celsius em Kelvin é %.2lf\n", celsius, kelvin); 
 			}
 		if(escolha2 == 3) {
 			printf("Digite o valor em Fahrenheit\n");
 			double fahrenheit, celsius;
 			scanf("%lf",&fahrenheit);
 			celsius = (fahrenheit - 32)/1.8;                  //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf graus Fahrenheit em Celsius é %.2lf\n", fahrenheit, celsius); 
 			}
        if(escolha2 == 4) {
 			printf("Digite o valor em Fahrenheit\n");
 			double fahrenheit, kelvin;
 			scanf("%lf",&fahrenheit);
 			kelvin = ((5*fahrenheit) + 2297)/9;             //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf graus Fahrenheit em Kelvin é %.2lf\n", fahrenheit, kelvin); 
 			}
        if(escolha2 == 5) {
 			printf("Digite o valor em Kelvin\n");
 			double kelvin, celsius;
 			scanf("%lf",&kelvin);
 			celsius = kelvin - 273;              //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf graus Kelvin em Celsius é %.2lf\n", kelvin, celsius); 
 			}
        if(escolha2 == 6) {
 			printf("Digite o valor em Kelvin\n");
 			double kelvin, fahrenheit;
 			scanf("%lf",&kelvin);
 			fahrenheit = ((9*kelvin) - 2297)/5;               //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf graus Kelvin em Fahrenheit é %.2lf\n", kelvin, fahrenheit); 
            
        }
 	    }
 	//condição para que o código passe a executar as conversoes de distâncias
 	if (escolha1 == 2) {
 	printf("Legal!! É sempre bom fazer a conversão de Distâncias.\n");
 		
 		printf("Qual o tipo de conversão você gostaria de fazer hoje?\n");
 		printf("1. Metros para Quilômetros\n");
 		printf("2. Metros para Milhas\n");
 		printf("3. Quilômetros para Metros\n");
 		printf("4. Quilômetros para Milhas\n");
 		printf("5. Milhas para Quilômetros\n");
 		printf("6. Milhas para Metros\n");
 		int escolha3;
 		double metros, quilometros, milhas;
 		scanf("%d",&escolha3);
 		//condições para que cada tipo específico de conversão de distãncia seja executada
 	    if(escolha3 == 1) {
 			printf("Digite o valor em Metros\n");
 			double metros,quilometros;
 			scanf("%lf",&metros);
 			quilometros = metros/1000;                //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Metros em Quilômetros é %.2lf\n", metros, quilometros); 
 			}
 		if(escolha3 == 2) {
 			printf("Digite o valor em Metros\n");
 			double metros, milhas;
 			scanf("%lf",&metros);
 			milhas = metros/1609;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Metros em Quilômetros é %.2lf\n", metros, quilometros); 
 			}
 		if(escolha3 == 3) {
 			printf("Digite o valor em Quilômetros\n");
 			double quilometros, metros;
 			scanf("%lf",&quilometros);
 			metros = quilometros*1000;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Quilômetros em Metros é %.2lf\n", quilometros, metros); 
 			}
        if(escolha3 == 4) {
 			printf("Digite o valor em Quilômetros\n");
 			double quilometros, milhas;
 			scanf("%lf",&quilometros);
 			milhas = quilometros/1.609;               //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Quilômetros em Milhas é %.2lf\n", quilometros, milhas); 
 			}
        if(escolha3 == 5) {
 			printf("Digite o valor em Milhas\n");
 			double milhas, quilometros;
 			scanf("%lf",&milhas);
 			quilometros = milhas*1.609;                  //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Milhas em Quilômetros é %.2lf\n", milhas, quilometros); 
 			}
        if(escolha3 == 6) {
 			printf("Digite o valor em Milhas\n");
 			double milhas, metros;
 			scanf("%lf",&milhas); 
 			metros = milhas*1609;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Milhas em Metros é %.2lf\n", milhas, metros); 
 			}	
 	}
 	//condição para que o código passe a executar as conversoes de velocidades
 	if (escolha1 == 3) {
 		printf("Legal!! É sempre bom fazer a conversão de Velocidades.\n");
 		
 		printf("Qual o tipo de conversão você gostaria de fazer hoje?\n");
 		printf("1. Km/h para Mts/s\n");
 		printf("2. Km/h para Mph\n");
 		printf("3. Mts/s para Km/h\n");
 		printf("4. Mts/s para Mph\n");
 		printf("5. Mph para Mts/s\n");
 		printf("6. Mph para Km/h\n");
 		int escolha4;
 		double kmh, mts, mph;
 		scanf("%d",&escolha4);
 		//condições para que cada tipo específico de conversão de velocidade seja executada
 	    if(escolha4 == 1) {
 			printf("Digite o valor em Km/h\n");
 			double kmh,mts;
 			scanf("%lf",&kmh);
 			mts = kmh/3,6;                  //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Km/h em Mts/s é %.2lf\n", kmh, mts); 
 			}
 		if(escolha4 == 2) {
 			printf("Digite o valor em Km/h\n");
 			double kmh, mph;
 			scanf("%lf",&kmh); 
 			mph = kmh/1.609;                     //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Km/h em Mph é %.2lf\n", kmh, mph); 
 			}
 		if(escolha4 == 3) {
 			printf("Digite o valor em Mts/s\n");
 			double mts, kmh;
 			scanf("%lf",&mts);
 			kmh = mts*3.6;                //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Mts/s em Km/h é %.2lf\n", mts, kmh); 
 			}
        if(escolha4 == 4) {
 			printf("Digite o valor em Mts/s\n");
 			double mts, mph;
 			scanf("%lf",&mts);
 			mph = mts*2.237;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Mts/s em Mph é %.2lf\n", mts, mph); 
 			}
        if(escolha4 == 5) {
 			printf("Digite o valor em Mph\n");
 			double mph, mts;
 			scanf("%lf",&mph);
 			mts = mph*2.237;                       //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Mph em Mts/s é %.2lf\n", mph, mts); 
 			}
        if(escolha4 == 6) {
 			printf("Digite o valor em Mph\n");
 			double mph, kmh;
 			scanf("%lf",&mph);
 			kmh = mph*1.609;                 //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Mph em Km/h é %.2lf\n", mph, kmh); 
 			}
 	}
 	//condição para que o código passe a executar as conversoes de peso
 	if (escolha1 == 4) {
		printf("Que legal!! É sempre bom fazer as conversão de pesos!\n");
		printf("Qual o tipo de conersão de peso você gostaria de fazer hoje?\n");
		printf("1. Quilogramas para gramas\n");
		printf("2. Quilogramas para toneladas\n");
		printf("3. Gramas para quilogramas\n");
		printf("4. Gramas para toneladas\n");
		printf("5. Toneladas para quilogramas\n");
		printf("6. Toneladas para gramas\n");
		int escolha5;
		double quilo,gr,ton;
		scanf("%d",&escolha5);
		//condições para que cada tipo específico de conversão de peso seja executada
		if (escolha5 == 1) {
			printf("Digite o valor em quilogramas\n");
			scanf("%lf",&quilo);
			gr = quilo*1000;                   //operação específica que a maquina vai fazer para esse tipo de conversão
			printf("%.2lf quilogramas em gramas é %.2lf\n", quilo,gr);

		}
		if (escolha5 == 2) {
			printf("Digite o valor em quilogramas\n");
			scanf("%lf",&quilo);
			ton = quilo/1000;                     //operação específica que a maquina vai fazer para esse tipo de conversão
			printf("%.2lf quilogramas em toneladas é %.4lf\n", quilo,ton);

		}
		if (escolha5 == 3) {
			printf("Digite o valor em gramas\n");
			scanf("%lf",&gr);
			quilo = gr/1000;                   //operação específica que a maquina vai fazer para esse tipo de conversão
			printf("%.2lf gramas em quilogramas é %.4lf\n", gr,quilo);

		}
		if (escolha5 == 4) {
			printf("Digite o valor em gramas\n");
			scanf("%lf",&gr);
			ton = gr/1000000;                        //operação específica que a maquina vai fazer para esse tipo de conversão
			printf("%.2lf gramas em toneladas é %.8lf\n", gr,ton);

		}
		if (escolha5 == 5) {
			printf("Digite o valor em toneladas\n");
			scanf("%lf",&ton);
			gr = ton*1000000;                     //operação específica que a maquina vai fazer para esse tipo de conversão
			printf("%.2lf toneladas em gramas é %.2lf\n", ton,gr);

		}
		if (escolha5 == 6) {
			printf("Digite o valor em toneladas\n");
			scanf("%lf",&ton);
			quilo = ton*1000;             //operação específica que a maquina vai fazer para esse tipo de conversão
			printf("%.2lf toneladas em quilogramas é %.2lf\n", ton,quilo);

		}
    }
         //condição para que o código passe a executar as conversoes de tempo
        if (escolha1 == 5) {
 		printf("Legal!! É sempre bom fazer a conversão de Tempos.\n");
 		
 		printf("Qual o tipo de conversão você gostaria de fazer hoje?\n");
 		printf("1. Segundo para Minuto\n");
 		printf("2. Minuto para Segundo\n");
 		printf("3. Segundo para Hora\n");
 		printf("4. Hora para Segundo\n");
 		printf("5. Minuto para Hora\n");
 		printf("6. Hora para Minuto\n");
		printf("7. Segundo para Dia\n");
		printf("8. Dia para Segundo\n");
		printf("9. Minuto para Dia\n");
		printf("10. Dia para Minuto\n");
		printf("11. Hora para Dia\n");
		printf("12. Dia para Hora\n");
		printf("13. Segundo para Ano(não bissexto)\n");
		printf("14. Ano(não bissexto) para Segundo\n");
		printf("15. Minuto para Ano(não bissexto)\n");
		printf("16. Ano(não bissexto) para Minuto\n");
		printf("17. Hora para Ano(não bissexto)\n");
		printf("18. Ano(não bissexto) para Hora\n");
		printf("19. Dia para Ano(não bissexto)\n");
		printf("20. Ano(não bissexto) para Dia\n");
		int escolha5;
 		double s, min, h, d, a;
 		scanf("%d",&escolha5);
 		//condições para que cada tipo específico de conversão de tempo seja executada
		if(escolha5 == 1) {
 			printf("Digite o valor em Segundo\n");
 			double s, min;
 			scanf("%lf",&s);
 			min = s/60;                      //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Segundo em Minuto é %.2lf\n", s, min); 
 			}
		if(escolha5 == 2) {
 			printf("Digite o valor em Minuto\n");
 			double s, min;
 			scanf("%lf",&min); 
 			s = min*60;                    //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Minuto em Segundo é %.2lf\n", min, s); 
 			}
		if(escolha5 == 3) {
 			printf("Digite o valor em Segundo\n");
 			double s, h;
 			scanf("%lf",&s);
 			h = s/3600;                     //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Segundo em Hora é %.2lf\n", s, h); 
 			}
		if(escolha5 == 4) {
 			printf("Digite o valor em Hora\n");
 			double s, h;
 			scanf("%lf",&h);
 			s = h*3600;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Hora em Segundo é %.2lf\n", h, s);
 			}
		if(escolha5 == 5) {
 			printf("Digite o valor em Minuto\n");
 			double min, h;
 			scanf("%lf",&min);
 			h = min/60;                //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Minuto em Hora é %.2lf\n", min, h); 
 			}
		if(escolha5 == 6) {
 			printf("Digite o valor em Hora\n");
 			double min, h;
 			scanf("%lf",&h);
 			min = h*60;                //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Hora em Minuto é %.2lf\n", h, min); 
 			}
		if(escolha5 == 7) {
 			printf("Digite o valor em Segundo\n");
 			double s, d;
 			scanf("%lf",&s);
 			d = s/86400;                    //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Segundo para Dia é %.2lf\n", s, d); 
 			}
		if(escolha5 == 8) {
 			printf("Digite o valor em Dia\n");
 			double s, d;
 			scanf("%lf",&d);
 			s = d*86400.00;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Dia para Segundo é %.2lf\n", d, s); 
 			}
		if(escolha5 == 9) {
 			printf("Digite o valor em Minuto\n");
 			double min, d;
 			scanf("%lf",&min);
 			d = min/1440;            //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Minuto para Dia é %.2lf\n", min, d); 
 			}
		if(escolha5 == 10) {
 			printf("Digite o valor em Dia\n");
 			double min, d;
 			scanf("%lf",&d);
 			min = d*1440;                  //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Dia para Minuto é %.2lf\n", d, min); 
 			}
		if(escolha5 == 11) {
 			printf("Digite o valor em Hora\n");
 			double h, d;
 			scanf("%lf",&h);
 			d = h/24;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Hora para Dia é %.2lf\n", h, d); 
 			}
		if(escolha5 == 12) {
 			printf("Digite o valor em Dia\n");
 			double h, d;
 			scanf("%lf",&d);
 			h = d*24;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Dia para Hora é %.2lf\n", d, h); 
 			}
		if(escolha5 == 13) {
 			printf("Digite o valor em Segundo\n");
 			double s, a;
 			scanf("%lf",&s);
 			a = s/31536000;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Segundo para Ano(não bissexto) é %.2lf\n", s, a); 
 			}
		if(escolha5 == 14) {
 			printf("Digite o valor em Ano(não bissexto)\n");
 			double s, a;
 			scanf("%lf",&a);
 			s = a*31536000;                  //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Ano(não bissexto) para Segundo é %.10lf\n", a, s); 
 			}
		if(escolha5 == 15) {
 			printf("Digite o valor em Minuto\n");
 			double min, a;
 			scanf("%lf",&min);
 			a = min/525600;             //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Minuto para Ano(não bissexto) é %.2lf\n", min, a); 
 			}
		if(escolha5 == 16) {
 			printf("Digite o valor em Ano(não bissexto)\n");
 			double min, a;
 			scanf("%lf",&a);
 			min = a*525600;              //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Ano(não bissexto) para Minuto é %.8lf\n", a, min); 
 			}
		if(escolha5 == 17) {
 			printf("Digite o valor em Hora\n");
 			double h, a;
 			scanf("%lf",&h);
 			a = h/8760;                              //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Hora para Ano(não bissexto) é %.2lf\n", h, a); 
 			}
		if(escolha5 == 18) {
 			printf("Digite o valor em Ano(não bissexto)\n");
 			double h, a;
 			scanf("%lf",&a);
 			h = a*8760;                          //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Ano(não bissexto) para Hora é %.6lf\n", a, h); 
 			}
		if(escolha5 == 19) {
 			printf("Digite o valor em Dia\n");
 			double d, a;
 			scanf("%lf",&d);
 			a = d/365;                  //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Dia para Ano(não bissexto) é %.2lf\n", d, a); 
 			}
		if(escolha5 == 20) {
 			printf("Digite o valor em Ano(não bissexto)\n");
 			double d, a;
 			scanf("%lf",&a);
 			d = a*365;                  //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Ano(não bissexto) para Dia é %.5lf\n", a, d); 
 			}
	}
	//condição para que o código passe a executar as conversoes de volume
	if (escolha1 == 6) {
 		printf("Legal!! É sempre bom fazer a conversão de Volumes.\n");
 		
 		printf("Qual o tipo de conversão você gostaria de fazer hoje?\n");
 		printf("1. m³ para Litro\n");
 		printf("2. Litro para m³\n");
 		printf("3. dm³ para Litro\n");
 		printf("4. Litro para dm³\n");
 		printf("5. cm³ para Litro\n");
 		printf("6. Litro para cm³\n");
		printf("7. m³ para mL\n");
 		printf("8. mL para m³\n");
 		printf("9. dm³ para mL\n");
 		printf("10. mL para dm³\n");
 		printf("11. cm³ para mL\n");
 		printf("12. mL para cm³\n");
		int escolha6;
 		double m3, dm3, cm3, l, ml;
 		scanf("%d",&escolha6);
 		//condições para que cada tipo específico de conversão de volume seja executada
		if(escolha6 == 1) {
 			printf("Digite o valor em m³\n");
 			double m3, l;
 			scanf("%lf",&m3);
 			l = m3*1000;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf m³ em Litro é %.2lf\n", m3, l); 
 			}
		if(escolha6 == 2) {
 			printf("Digite o valor em Litro\n");
 			double m3, l;
 			scanf("%lf",&l);
 			m3 = l/1000;                  //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf m³ em Litro é %.2lf\n", m3, l); 
 			}
		if(escolha6 == 3) {
 			printf("Digite o valor em dm³\n");
 			double dm3, l;
 			scanf("%lf",&dm3);
 			l = dm3;            //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf dm³ em Litro é %.2lf\n", dm3, l); 
 			}
		if(escolha6 == 4) {
 			printf("Digite o valor em Litro\n");
 			double dm3, l;
 			scanf("%lf",&l);
 			dm3 = l;                //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf Litro em dm³ é %.2lf\n", l, dm3); 
 			}
		if(escolha6 == 5) {
 			printf("Digite o valor em cm³\n");
 			double cm3, l;
 			scanf("%lf",&cm3);
 			l = (cm3)*1000;                          //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf cm³ em Litro é %.2lf\n", cm3, l); 
 			}
		if(escolha6 == 6) {
 			printf("Digite o valor em Litro\n");
 			double cm3, l;
 			scanf("%lf",&l);
 			cm3 = l/1000;                        //operação específica que a maquina vai fazer para esse tipo de conversão 
 			printf("%.2lf Litro em cm³ é %.2lf\n", l, cm3); 
 			}
		if(escolha6 == 7) {
 			printf("Digite o valor em m³\n");
 			double m3, ml;
 			scanf("%lf",&m3);
 			ml = m3*1000000;               //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf m³ em mL é %.2lf\n", m3, ml); 
			}
		if(escolha6 == 8) {
 			printf("Digite o valor em mL\n");
 			double m3, ml;
 			scanf("%lf",&ml);
 			m3 = 1000000*ml;                     //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf mL em m³ é %.2lf\n", ml, m3); 
 			}
		if(escolha6 == 9) {
 			printf("Digite o valor em dm³\n");
 			double dm3, ml;
 			scanf("%lf",&dm3);
 			ml = dm3/1000;                  //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf dm³ em mL é %.2lf\n", dm3, ml); 
 			}
		if(escolha6 == 10) {
 			printf("Digite o valor em mL\n");
 			double dm3, ml;
 			scanf("%lf",&ml);
 			dm3 = 1000*ml;         //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf mL em dm³ é %.2lf\n", ml, dm3); 
 			}
		if(escolha6 == 11) {
 			printf("Digite o valor em cm³\n");
 			double cm3, ml;
 			scanf("%lf",&cm3);
 			ml = cm3;                   //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf cm³ em mL é %.2lf\n", cm3, ml); 
 			}
		if(escolha6 == 12) {
 			printf("Digite o valor em mL\n");
 			double cm3, ml;
 			scanf("%lf",&ml);
 			cm3 = ml;                  //operação específica que a maquina vai fazer para esse tipo de conversão
 			printf("%.2lf mL em cm³ é %.2lf\n", ml, cm3); 
 			}
    }
	//condição para que o código mostre os creditos 
 	if (escolha1 == 7) {
        printf("             .=++-:.:-+==.                              .=++-:.:-+==.                             .=++-:.:-+==.\n");
        printf("          ..*.             :#.                      ..*.             :#.                      ..*.             :#.\n"); 
        printf("    .-++=:+.                 .+..==:.         .-++=:+.                 .+..==:.         .-++=:+.                 .+..==:.\n");
        printf("  .*.  .*:                     --.  .=:.    .*.  .*:                     --.  .=:.    .*.  .*:                     --.  .=:.\n");     
        printf(" -:   .+. .+=:..:-=++==:..:-+=. .=    .+.  -:   .+. .+=:..:-=++==:..:-+=. .=    .+.  -:   .+. .+=:..:-=++==:..:-+=. .=    .+.\n");        
        printf(":+    =: +.    .-.     .-.    :* =:    .+ :+    =: +.    .-.     .-.    :* =:    .+ :+    =: +.    .-.     .-.    :* =:    .+\n");          
        printf(":+.   = .=     #@#    .#@#     -. *   .+ :+.   = .=     #@#     .#@#     -. *    .+ :+.   = .=    #@#     .#@#     -. *    .+\n");          
        printf(" :*:..- .=     -#:     =#:     -. =  .-=   :*:..- .=     -#:     =#:     -. =  .-=   :*:..- .=     -#:     =#:     -. =  .-=\n");   
        printf("    .:= .=        -**+:       .*  +::.        .:= .=        -**+:       .*  +::.        .:= .=        -**+:       .*  +::.\n");
        printf("      +  --.     .+=-=+       +. .*             +  --.     .+=-=+       +. .*             +  --.     .+=-=+       +. .*\n");
        printf("      -= .#.                 .*: +.             -= .#.                 .*: +.             -= .#.                 .*: +.\n");
        printf("       -+:                     :*-               -+:                     :*-               -+:                     :*-\n");
        printf("       .@  .-               .*  @.               .@  .-               .*  @.               .@  .-               .*  @.\n");
        printf("        =:   :+-.       ..++.  .@.                =:   :+-.       ..++.  .@.                =:   :+-.       ..++.  .@.\n");
        printf("         +-        ...        .*                   +-        ...        .*                   +-        ...        .*\n");
        printf("          .-+-             .++.                     .-+-             .++.                     .-+-             .++.\n");
        printf("               ..-*####+:.                               ..-*####+:.                               ..-*####+:.\n");
        printf("	    Matheus Barriquelo                        Moisés Lourenço                             Pedro Cabral\n");
 	}
 	//condição para que o loop se encerre e o codigo acabe
 	if (escolha1==8) break;
 	}
   
    return 0; 
}
