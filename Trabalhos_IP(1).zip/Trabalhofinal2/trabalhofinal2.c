
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>

double peso, altura, imc;
char nome[100], biotipo[10];
int idade;


void red () {
  printf("\033[1;31m");
}
void reset () {
  printf("\033[0m");
}

void menu();
void leituradados ();
void credito ();
int calculo ();
void treino (char *p);
void bancotreino (int **mtz);
void final ();

int main ()
{
    red();
    printf ("                 @@+.\n");                                                    
    printf ("                .@..:@@@@.\n");                                               
    printf ("                @@      .:@@*            =@@#\n");                            
    printf ("                @.   .      :@@        .@@.   *@@.\n");                       
    printf ("               .@.   ..: :    *@      @@.        @@\n");                      
    printf ("                @.    @. .. .  =@    @@        @@@.\n");                      
    printf ("                @@   *.@+ . *   @@  =@.     .@@\n");                          
    printf ("                .@.  .. @@. ..  *@  @=     #@.\n");                           
    printf ("                 =@. .  .@@..:  .@.:@     @@\n");                             
    printf ("                  .@*  .@..@@.   @=@@    @@\n");                              
    printf ("                    @@=    .@@@  +@@@   .@.\n");                              
    printf ("                  .@@@@@@@@@@@@@*.@@   @@ .@@@@@@@@@@@@@#\n");               
    printf ("               .@@@.            .#@@@.  @@@=.            .@@@\n");            
    printf ("             .@@                    .@@@.                   .@@.\n");         
    printf ("            @@.                                               .@@\n");        
    printf ("           @#                                                   @@\n");       
    printf ("          @*                                                     @@\n");      
    printf ("         @@              ███████████  ███   █████                 @@\n");     
    printf ("        .@.               ███      █         ███                  .@.\n");    
    printf ("        @@                ███   █    ████  ███████                 @*\n");    
    printf ("        @@                ███████     ███    ███                   @@\n");    
    printf ("        @*                ███   █     ███    ███                   @@\n");    
    printf ("        @*                ███         ███    ███ ███               @@\n");    
    printf ("        @@               █████       █████    █████                @@\n");    
    printf ("        +@                                                        .@.\n");    
    printf ("        .@.                                                       =@\n");     
    printf ("         @@                                                      .@*\n");     
    printf ("          @:                                                     #@\n");      
    printf ("          -@.                   █████████                       .@.\n");      
    printf ("           @@.                 ███     ███                     .@#\n");       
    printf ("            @@                ███                              @@\n");        
    printf ("             @@.              ███                            .@@\n");         
    printf ("              *@.              ███     ███                  .@-\n");          
    printf ("               .@@              █████████                 .@@\n");            
    printf ("                 @@:                                     *@*\n");             
    printf ("                   @@+                                 *@*\n");               
    printf ("                     =@@.                           :@@.\n");                 
    printf ("                        -@@@*.      . +.       . @@@.\n");                    
    printf ("                              *@@@@@* . #@@@@@#\n");
    reset();
    
    printf ("Seja bem vindo(a) ao nosso programa!\n");
    printf ("Aqui nos ajudaremos voce a encontrar sua melhor versão!\n");
    printf ("Por favor, escolha uma das opções:\n\n");
    
    menu ();

    return 0;
}

void menu ()
{
    int opcao;

    do
    {
        printf ("1. Continuar no programa\n");
        printf ("2. Creditos\n");
        printf ("3. Sair\n\n");

        scanf("%d%*c", &opcao);

        if (opcao == 1)
        {
            printf ("\n------- Excelente escolha! Para continuarmos, preencha os campos abaixo: -------\n\n");
            leituradados ();
        }

        if (opcao == 2)
        {
            credito ();
            printf ("\n");
        }

        if (opcao == 3)
        {
            printf ("\nJá vai? Tudo bem! Espero que tenha gostado =)\n");
            break;
        }

        if (opcao < 1 || opcao > 3)
        {
            printf ("\nOps! Insira os numeros corretos listados no menu\n\n");
        }

    } while (1);
}

void leituradados ()
{
    printf ("Nome: "); 
    fgets (nome, 100, stdin);
    printf ("Idade: ");
    scanf ("%d", &idade);
    printf ("Peso: ");
    scanf ("%lf", &peso);
    printf ("Altura (ex.: 1.80 = 1 metro e 80 cm): ");
    scanf ("%lf", &altura);
    getchar();
    printf ("Escolha seu biotipo (Ectomorfo, Mesomorfo ou Endomorfo -escreva da forma indicada-): ");
    fgets (biotipo, 10, stdin);

    system ("clear");

    calculo ();
    
    final ();
}

int calculo ()
{
    sleep (5);

    imc = peso/(altura * altura);

    if (imc < 18.50) //Baixo Peso
    {
        if (imc < 16.00)
        {
            return 1;
            //Magreza severa
        }

        else if (imc >= 16.00 && imc < 17.00)
        {
            return 2;
            //Magreza moderada
        }

        else if (imc >= 17.00 && imc < 18.50)
        {
            return 3;
            //Magreza leve
        }
    }

    else if (imc >= 18.50 && imc < 25.00) return 4; //Peso adequado

    else if (imc >= 25.00) //Excesso de Peso
    {
        if (imc >= 25.00 && imc < 30.00)
        {
            return 5;
            //Pré-obeso
        }

        else if (imc >= 30.00 && imc <35.00)
        {
            return 6;
            //Obesidade grau I
        }

        else if (imc >= 35.00 && imc < 40.00)
        {
            return 7;
            //Obesidade grau II
        }
        else if (imc > 40.00)
        {
            return 8;
            //Obesidade grau III
        }
    }
}

void final ()
{
    int x;

    printf ("-------- Pronto! Aqui esta sua ficha: --------\n\n");

    printf ("Sr(a). %s", nome);
    printf ("Idade: %d anos\n", idade);
    printf ("Peso: %.2lf Kg\n", peso);
    printf ("Altura: %.2lf m\n", altura);
    printf ("Biotipo: %s\n", biotipo);

    printf ("\n-------- Aqui está alguns dados e acoes para melhorar seu fisico e sua saude: --------\n\n");

    x = calculo ();

    printf ("Seu IMC é: %.2lf\n", imc);

    if (x == 1)
    {
        printf ("A categoria que você se encontra é: Magreza Severa!\n");
        printf ("Não é um quadro animador, mas tem conserto e eu vou te ajudar nisso!\n\n");

        printf ("Acoes recomendadas:\n\n");

        printf ("1. Ingerir os nutrientes essenciais para manter e melhorar o funcionamento do corpo\n");
        printf ("2. Comer o suficiente para aumentar as calorias e a energia do corpo\n");
        printf ("3. Ter uma boa noite de sono, praticar atividades fisicas e ingerir no minimo 1.5L de agua diariamente!\n\n");
    }

    else if (x == 2)
    {
        printf ("A categoria que você se encontra é: Magreza Moderada!\n");
        printf ("Não é um quadro animador, mas podia ser pior. Eu vou te ajudar nisso!\n\n");

        printf ("Acoes recomendadas:\n\n");

        printf ("1. Ingerir os nutrientes essenciais para manter e melhorar o funcionamento do corpo\n");
        printf ("2. Comer o suficiente para aumentar as calorias e a energia do corpo\n");
        printf ("3. Ter uma boa noite de sono, praticar atividades fisicas e ingerir no minimo 1.5L de agua diariamente!\n\n");
    }

    else if (x == 3)
    {
        printf ("A categoria que você se encontra é: Magreza Leve!\n");
        printf ("É um quadro animador, mas pode ser melhor do que está, concorda? Eu vou te ajudar nisso!\n\n");

        printf ("Acoes recomendadas:\n\n");

        printf ("1. Consumir 1,6g/Kg de proteína por dia\n");
        printf ("2. Adicionar de 300 a 500 calorias totais na alimentação\n");
        printf ("3. Recomenda-se 6 refeições diárias com intervalos de 3 horas no máximo\n");
        printf ("4. Ter uma boa noite de sono, praticar atividades fisicas e ingerir no minimo 1.5L de agua diariamente!\n\n");
    }

    else if (x == 4)
    {
        printf ("A categoria que você se encontra é: Peso adequado!\n");
        printf ("Ótimo quadro, bom trabalho até aqui. Vou apenas te indicar a buscar um aconselhamento nutricional mais profissional para os seus objetivos. Parabens!\n");
        printf ("Caso queira algumas acoes recomendadas para manter essa condicao, aqui esta:\n\n");

        printf ("Acoes recomendadas:\n\n");

        printf ("1. Consumir 1,6g/Kg de proteína por dia\n");
        printf ("2. Adicionar de 300 a 500 calorias totais na alimentação\n");
        printf ("3. Recomenda-se 6 refeições diárias com intervalos de 3 horas no máximo\n");
        printf ("4. Ter uma boa noite de sono, praticar atividades fisicas e ingerir no minimo 1.5L de agua diariamente!\n\n");
    }

    else if (x == 5)
    {
        printf ("A categoria que você se encontra é: Pre obeso!\n");
        printf ("Eita! Não é uma noticia boa, mas podia ser pior. Ainda podemos reverter essa situacao e atingir mais rapido seus objetivos. Eu vou te ajudar nisso!\n\n");

        printf ("Acoes recomendadas:\n\n");

        printf ("1. Consumir boa quantidade de proteína\n");
        printf ("2. Dieta balanceada\n");
        printf ("3. Recomenda-se fazer uma dieta low carb e fazer exercicios aerobicos\n");
        printf ("4. Ter uma boa noite de sono, praticar atividades fisicas e ingerir no minimo 1.5L de agua diariamente!\n\n");
    }

    else if (x == 6)
    {
        printf ("A categoria que você se encontra é: Obesidade grau I!\n");
        printf ("Eita! Não é uma noticia boa, mas ainda podemos reverter essa situacao. Eu vou te ajudar nisso!\n\n");

        printf ("Acoes recomendadas:\n\n");

        printf ("1. Consumir boa quantidade de proteína\n");
        printf ("2. Dieta balanceada\n");
        printf ("3. Recomenda-se fazer uma dieta low carb e fazer exercicios aerobicos\n");
        printf ("4. Ter uma boa noite de sono, praticar atividades fisicas e ingerir no minimo 1.5L de agua diariamente!\n\n");
    }

    else if (x == 7)
    {
        printf ("A categoria que você se encontra é: Obesidade grau II!\n");
        printf ("Eita! Não é uma noticia boa, mas depende da sua forca de vontade de querer mudar e de conselhor tecnicos. Eu vou te ajudar nisso!\n\n");

        printf ("Acoes recomendadas:\n\n");

        printf ("1. Consumir boa quantidade de proteína\n");
        printf ("2. Dieta balanceada\n");
        printf ("3. Recomenda-se fazer uma dieta low carb e fazer exercicios aerobicos\n");
        printf ("4. Ter uma boa noite de sono, praticar atividades fisicas e ingerir no minimo 1.5L de agua diariamente!\n\n");
    }

    else if (x == 8)
    {
        printf ("A categoria que você se encontra é: Obesidade grau III!\n");
        printf ("Eita! É uma pessima noticia, sua saude nao esta boa, sua vida esta sendo afetada por conta disso e resolveu buscar ajuda. Calma, eu vou te ajudar nisso!\n\n");

        printf ("Acoes recomendadas:\n\n");

        printf ("1. Consumir boa quantidade de proteína\n");
        printf ("2. Dieta balanceada\n");
        printf ("3. Recomenda-se fazer uma dieta low carb e fazer exercicios aerobicos\n");
        printf ("4. Ter uma boa noite de sono, praticar atividades fisicas e ingerir no minimo 1.5L de agua diariamente!\n\n");
    }

    
    if (strcmp (biotipo, "Ectomorfo") == 0)
    {
        printf ("Recomenda-se uma dieta:\n\n");
        printf ("1. Carboidratos (Paes, Massas, Doces), 2. Lipídeos saudáveis (Azeite, Banha, Oleo Vegetal), 3. Proteínas no geral (Ovo, Carne Vermelha e Branca), 4. Vegetais, Leguminosas, Tubérculos e Frutas, 5. Cereais e Graos (Arroz, Feijao, Trigo)\n");
        printf ("Evitar: Alimentos com Açúcar refinado, alimentos industrializados, cereais refinados, alimentos embutidos, alimentos ricos em gordura\n\n");
    }
    
    if (strcmp (biotipo, "Mesomorfo") == 0)
    {
        printf ("Recomenda-se uma dieta:\n\n");
        printf ("1. Carboidratos (Paes), 2. Lipídeos saudáveis (Azeite, Oleo Vegetal), 3. Proteínas no geral (Ovo, Carne Vermelha e Branca), 4. Vegetais, Leguminosas, Tubérculos e Frutas, 5. Cereais e Graos (Arroz, Feijao)\n");
        printf ("Evitar: Alimentos com alto teor de gordura, Embutido, Alimento rico em açúcar, Cereais refinados, Alimentos industrializados, Bebidas alcoólicas\n\n");
    }

    if (strcmp (biotipo, "Endomorfo") == 0)
    {
        printf ("Recomenda-se uma dieta:\n\n");
        printf ("1. Pouco Carboidratos, 2. Pouco Lipídeos, 3. Proteínas no geral (Ovo, Carne Vermelha e Branca), 4. Vegetais, Leguminosas, Tubérculos e Frutas, 5. Cereais e Graos (Arroz, Feijao)\n");
        printf ("Evitar: Alimentos ricos em açúcar, alimentos industrializados, Cereais refinados, Alimentos ricos em gordura\n\n");
    }

    treino (biotipo);

    printf ("\nÉ isso! Muito obrigado por utilizar nosso programa e desejo-lhe sorte nessa nova caminhada =)\n\n");
}

void treino (char *p)
{
    int **banco, i, j;

    banco = (int **) malloc (5 * sizeof (int *));

    for (i=0; i<5; i++)
    {
        banco[i] = (int *) malloc (2 * sizeof (int));
    }

    bancotreino (banco);

    printf ("Seu conjunto de treino recomendado:\n\n");

    printf ("Treino e Cardio:\n\n");

    for (i=0; i<5; i++)
    {
        for (j=0; j<2; j++)
        {

            if (strcmp (p, "Ectomorfo") == 0)
            {
                if (banco[i][j] == 1) printf ("Segunda: A (Peitoral, Abdomen, Triceps, Ombro) e ");
                if (banco[i][j] == 2) printf ("Terca: B (Dorsal, Ombro, Bicepes, Lombar) e ");
                if (banco[i][j] == 3) printf ("Quarta: C (Pernas) e ");
                if (banco[i][j] == 4) printf ("Quinta: A (Peitoral, Abdomen, Triceps, Ombro) e ");
                if (banco[i][j] == 5) printf ("Sexta: B (Dorsal, Ombro, Bicepes, Lombar) e ");

                if (banco[i][j] == 6) printf ("Esteira\n");
                if (banco[i][j] == 7) printf ("Escada\n");
                if (banco[i][j] == 8) printf ("Sem cardio\n");
                if (banco[i][j] == 9) printf ("Escada\n");
                if (banco[i][j] == 10) printf ("Esteira\n");
            }
            else if (strcmp (p, "Mesomorfo") == 0)
            {
                if (banco[i][j] == 1) printf ("Segunda: C (Pernas) e ");
                if (banco[i][j] == 2) printf ("Terca: B (Dorsal, Ombro, Bicepes, Lombar) e ");
                if (banco[i][j] == 3) printf ("Quarta: A (Peitoral, Abdomen, Triceps, Ombro) e ");
                if (banco[i][j] == 4) printf ("Quinta: C (Pernas) e ");
                if (banco[i][j] == 5) printf ("Sexta: B (Dorsal, Ombro, Bicepes, Lombar) e ");

                if (banco[i][j] == 6) printf ("Sem cardio\n");
                if (banco[i][j] == 7) printf ("Escada\n");
                if (banco[i][j] == 8) printf ("Esteira\n");
                if (banco[i][j] == 9) printf ("Sem cardio\n");
                if (banco[i][j] == 10) printf ("Esteira\n");
            }

            else if (strcmp (p, "Endomorfo") == 0)
            {
                if (banco[i][j] == 1) printf ("Segunda: B (Dorsal, Ombro, Bicepes, Lombar) e ");
                if (banco[i][j] == 2) printf ("Terca: A (Peitoral, Abdomen, Triceps, Ombro) e ");
                if (banco[i][j] == 3) printf ("Quarta: C (Pernas) e ");
                if (banco[i][j] == 4) printf ("Quinta: B (Dorsal, Ombro, Bicepes, Lombar) e ");
                if (banco[i][j] == 5) printf ("Sexta: A (Peitoral, Abdomen, Triceps, Ombro) e ");

                if (banco[i][j] == 6) printf ("Esteira\n");
                if (banco[i][j] == 7) printf ("Escada\n");
                if (banco[i][j] == 8) printf ("Esteira\n");
                if (banco[i][j] == 9) printf ("Escada\n");
                if (banco[i][j] == 10) printf ("Esteira\n");
            }
        }
    }

    for (i=0; i<5; i++)
    {
        free (banco[i]);
    }
    free (banco);
}

void bancotreino (int **mtz)
{
    //Ectomorfo                                     
    mtz[0][0] = 1; //Treino A na segunda
    mtz[1][0] = 2; //Treino B na terça
    mtz[2][0] = 3; //Treino C na quarta
    mtz[3][0] = 4; //Treino A na quinta
    mtz[4][0] = 5; //Treino B na sexta

    mtz[0][1] = 6; //Esteira
    mtz[1][1] = 7; //Escada
    mtz[2][1] = 8; //Por conta do treino C
    mtz[3][1] = 9; //Escada 
    mtz[4][1] = 10; //Esteira

    //Mesomorfo
                    //Treino C na segunda
                    //Treino B na terça
                    //Treino A na quarta
                    //Treino C na quinta
                    //Treino B na sexta

                    //Por conta do treino C
                    //Escada 
                    //Esteira
                    //Por conta do treino C
                    //Esteira

    //Endomorfo
                    //Treino B na segunda
                    //Treino A na terça
                    //Treino C na quarta
                    //Treino B na quinta
                    //Treino A na sexta

                    //Esteira
                    //Escada 
                    //Esteira 
                    //Escada 
                    //Esteira 
    
}

void credito ()
{
        printf("             .=++-:.:-+==.                              .=++-:.:-+==.                             .=++-:.:-+==.\n");
        printf("          ..*.             :#.                      ..*.             :#.                      ..*.             :#.\n"); 
        printf("    .-++=:+.                 .+..==:.         .-++=:+.                 .+..==:.         .-++=:+.                 .+..==:.\n");
        printf("  .*.  .*:                     --.  .=:.    .*.  .*:                     --.  .=:.    .*.  .*:                     --.  .=:.\n");     
        printf(" -:   .+. .+=:..:-=++==:..:-+=. .=    .+.  -:   .+. .+=:..:-=++==:..:-+=. .=    .+.  -:   .+. .+=:..:-=++==:..:-+=. .=    .+.\n");        
        printf(":+    =: +.    .-.     .-.    :* =:    .+ :+    =: +.    .-.     .-.    :* =:    .+ :+    =: +.    .-.     .-.    :* =:    .+\n");          
        printf(":+.   = .=     #@#    .#@#     -. *   .+ :+.   = .=     #@#     .#@#     -. *    .+ :+.   = .=    #@#     .#@#     -. *    .+\n");          
        printf(" :*:..- .=     -#:     =#:     -. =  .-=   :*:..- .=     -#:     =#:     -. =  .-=   :*:..- .=     -#:     =#:     -. =  .-=\n");   
        printf("    .:= .=        -**+:       .*  +::.        .:= .=        -**+:       .*  +::.        .:= .=        -**+:       .*  +::.\n");
        printf("      +  --.     .+=-=+       +. .*             +  --.     .+=-=+       +. .*             +  --.     .+=-=+       +. .*\n");
        printf("      -= .#.                 .*: +.             -= .#.                 .*: +.             -= .#.                 .*: +.\n");
        printf("       -+:                     :*-               -+:                     :*-               -+:                     :*-\n");
        printf("       .@  .-               .*  @.               .@  .-               .*  @.               .@  .-               .*  @.\n");
        printf("        =:   :+-.       ..++.  .@.                =:   :+-.       ..++.  .@.                =:   :+-.       ..++.  .@.\n");
        printf("         +-        ...        .*                   +-        ...        .*                   +-        ...        .*\n");
        printf("          .-+-             .++.                     .-+-             .++.                     .-+-             .++.\n");
        printf("               ..-*####+:.                               ..-*####+:.                               ..-*####+:.\n");
        printf("	    Matheus Barriquelo                        Moisés Lourenço                             Pedro Cabral\n");

}

